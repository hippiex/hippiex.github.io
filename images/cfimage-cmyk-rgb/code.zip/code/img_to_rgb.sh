#!/bin/bash
infile=$1
outfile=$2
/usr/bin/convert $infile -strip -colorspace rgb -quality 100  $outfile
echo "Convert Finished"
exit 0
